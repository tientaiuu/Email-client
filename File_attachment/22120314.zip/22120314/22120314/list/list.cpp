#include <iostream>
using namespace std;

struct Node
{
	int key;
	Node* pNext;
};
struct List
{	
	Node* pHead;
	Node* pTail;
};
void init(List& s)
{
	s.pHead = NULL;
	s.pTail = NULL;
}

Node* makeNode(int x)
{
	Node* newNode = new Node;
	newNode->key = x;
	newNode->pNext = NULL;
	return newNode;	
}
bool isEmpty(List* s)
{
	return (s->pHead == NULL);
}
void addHead(List*& s, Node* node)
{
	if (isEmpty(s))
	{
		s->pHead = node;
		return;
	}
	node->pNext = s->pHead;
	s->pHead = node;
}
void delHead(List*& s)
{
	if (!isEmpty(s))
	{
		Node* temp = s->pHead;
		s->pHead = temp->pNext;
		delete temp;
	}
}

void addTail(List*& s, Node* node)
{
	
	if (isEmpty(s))
	{
		s->pHead = node;
		return;
	}
	s->pTail->pNext = node;
	s->pTail = node;
}

void delTail(List*& s)
{
	if (!isEmpty(s))
	{
		Node* temp = s->pTail;
		s->pTail->pNext = temp;
		delete temp;
	}
}
void insertNode(List*& s, Node* node, int pos)
{
	if (pos == 0 || isEmpty(s))
	{
		s->pHead = node;
		return;
	}
	Node* current = s->pHead;
	for (int i = 0; i < pos - 1; i++)
	{
		if (current == NULL)
		{
			cout << "Position doesn't exist" << endl;
			return;
		}
		current = current->pNext;
	}
	node->pNext = current->pNext;
	current->pNext = node;


}

void delNode(List*& s, Node* node, int pos)
{
	if (isEmpty(s))
	{
		cout << " Empty List" << endl;
		return;
	}
	if (pos == 0)
	{
		Node* temp = s->pHead;
		s->pHead = s->pHead->pNext;
		delete temp;
		return;
	}
	Node* current = s->pHead;
	for (int i = 0; i < pos - 1; i++)
	{
		if (current->pNext == NULL)
		{
			cout << "Position doesn't exist" << endl;
			return;
		}
		current = current->pNext;
	}
	Node* temp = current->pNext;
	current->pNext = current->pNext->pNext;
	delete temp;

}

void reverseList(List* s)
{
	Node* prev = NULL;
	Node* current = s->pHead;
	Node* next = NULL;
	while (current != NULL)
	{
		next = current->pNext;
		current->pNext = prev;
		prev = current;
		current = next;
	}
	s->pHead = prev;	
}
void removeAll(List& s)
{
	Node* current = s.pHead;
	while (current != NULL)
	{
		Node* temp = current;
		current = current->pNext;
		delete temp;
	}
	s.pHead = NULL;
	s.pTail = NULL;
}
void printElements(List s)
{
	while (s.pHead != NULL)
	{
		cout << s.pHead->key << " ";
		s.pHead = s.pHead->pNext;
	}
	cout << endl;
}