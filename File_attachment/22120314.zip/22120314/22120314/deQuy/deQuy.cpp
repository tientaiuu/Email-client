#include <iostream>
using namespace std;

int sum_square(int n)
{
	if (n < 0) return 0;
	return n * n + sum_square(n - 1);
}

int fib(int n)
{
	if (n == 1 || n == 0)
	{
		return 1;
	}
	return fib(n - 1) + fib(n - 2);
}
int recursion_binary_search(int* a, int left, int right, int key)
{
	int mid = left + (right - left) / 2;
	if (a[mid] == key) return mid;
	if (mid == left) return -1;
	if (a[mid] > key)
	{
		recursion_binary_search(a, left, mid - 1, key);
	}
	else
	{
		recursion_binary_search(a, mid + 1, right, key);	
	}
}
int main()
{
	cout << "Sum: " << sum_square(5) << endl;
	cout << "Fib: ";
	for (int i = 0; i < 20; i++)
	{
		cout << fib(i) << " ";
	}
	int n = 5;
	int* a = new int[n];
	cout << endl;
	cout << "Input array: ";
	for (int i = 0; i < n; i++)
	{
		cin >> a[i];
	}
	cout << recursion_binary_search(a, 0, 5, 3);
}

