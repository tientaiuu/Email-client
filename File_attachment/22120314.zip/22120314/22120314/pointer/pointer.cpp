#include <iostream>
using namespace std;
void input_array(int*& a, int& n)
{
    a = new int[n];
    for (int i = 0; i < n; i++)
    {
        cin >> *(a + i);
    }
}
void print_array(int* a, int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << *(a + i) << " ";
    }
}
int find_max(int* a, int n)
{
    int max = a[0];
    for (int i = 0; i < n; i++)
    {
        if (max < *(a + i))
        {
            max = *(a + i);
        }
    }
    return max;
}

int find_min(int* a, int n)
{
    int min = a[0];
    for (int i = 0; i < n; i++)
    {
        if (min > *(a + i))
        {
            min = *(a + i);
        }
    }
    return min;
}
int sum_array(int* a, int n)
{
    int sum = 0;
    for (int i = 0; i < n; i++)
    {
        sum += *(a + i);
    }
    return sum;
}
bool isPrime(int n)
{
    int count = 0;
    if (n < 2) return false;
    else {

        for (int i = 2; i <= sqrt(n); i++)
        {
            if (n % i == 0)
            {
                return false;
            }
        }
        return true;
    }
}
int count_prime(int* a, int n)
{
    int count = 0;
    for (int i = 0; i < n; i++)
    {
        if (isPrime(a[i]) == true)
            count++;
    }
    return count;
}
void reverse_array(int*& a, int n)
{
    for (int i = 0; i < n / 2; i++)
    {
        int temp = *(a + i);
        *(a + i) = *(a + (n - 1 - i));
        *(a + (n - 1 - i)) = temp;
    }
}
int linear_search(int* a, int n, int key)
{
    for (int i = 0; i < n; i++)
    {
        if (*(a + i) == key)
            return i;
    }
    return -1;
}
int binary_search(int* a, int n, int key)
{
    int L = 0;
    int R = n - 1;
    int mid;
    while (L <= R)
    {
        mid = L + (R - L) / 2;
        if (*(a + mid) == key) return mid;
        else if (*(a + mid) < key) L = mid + 1;
        else R = mid - 1;
    }
    return -1;
}
int main()
{
    int* a;
    int n = 5;
    cout << "Input array: ";
    input_array(a, n);
    cout << "Array: ";
    print_array(a, n);
    cout << endl;
    cout << "Max is: " << find_max(a, n) << endl;
    cout << "Min is: " << find_min(a, n) << endl;
    cout << "Sum of array: " << sum_array(a, n) << endl;
    cout << "Num of prime: " << count_prime(a, n) << endl;
    reverse_array(a, n);
    cout << "reverseArray: ";
    print_array(a, n);
    cout << endl;
    int key = 5;
    cout << "Search: " << key << endl;
    cout << "Linear search: " << linear_search(a, n, key) << endl;
    cout << "Binary search: " << binary_search(a, n, key) << endl;
    delete[] a;
}
